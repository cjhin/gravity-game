void drawCircle(float x, float y, float r);
void drawBox(float x1, float y1, float x2, float y2);
void drawString(char* str, int x, int y, int h);
